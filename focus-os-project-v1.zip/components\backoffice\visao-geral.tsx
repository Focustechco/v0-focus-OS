"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  FileText,
  Users,
  ClipboardList,
  FolderOpen,
  Plus,
  Upload,
  Clock,
  AlertTriangle,
} from "lucide-react"
import { useSidebarStats } from "@/lib/hooks/use-sidebar-stats"

export function VisaoGeral() {
  const { stats } = useSidebarStats()

  const statCards = [
    { label: "Contratos Ativos", value: "0", icon: FileText, change: "Atualizado agora" },
    { label: "Tarefas ADM", value: "0", icon: ClipboardList, change: "Atualizado agora" },
    { label: "Clientes", value: stats.backlog || "0", icon: Users, change: "Total Leads" },
    { label: "Docs Pendentes", value: "0", icon: FolderOpen, change: "Atualizado agora" },
  ]

  const quickActions = [
    { label: "Novo Contrato", icon: FileText },
    { label: "Add Cliente", icon: Users },
    { label: "Upload Doc", icon: Upload },
    { label: "Nova Tarefa", icon: Plus },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl font-display font-bold text-white tracking-wide">BACKOFFICE / COMMAND CENTER</h2>
        <p className="text-neutral-500 text-sm font-mono mt-1">administracao centralizada</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <Card key={stat.label} className="bg-[#141414] border-[#2a2a2a] hover:border-orange-500/30 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-neutral-500 text-xs font-mono tracking-wider mb-1">{stat.label.toUpperCase()}</p>
                  <p className="text-3xl font-display font-bold text-white">{stat.value}</p>
                  <p className="text-neutral-600 text-xs font-mono mt-1">{stat.change}</p>
                </div>
                <div className="w-10 h-10 rounded bg-orange-500/10 flex items-center justify-center">
                  <stat.icon className="w-5 h-5 text-orange-500" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-3">
        {quickActions.map((action) => (
          <Button
            key={action.label}
            variant="outline"
            className="bg-transparent border-orange-500/30 text-orange-500 hover:bg-orange-500/10 hover:border-orange-500 font-mono text-xs tracking-widest uppercase"
          >
            <action.icon className="w-4 h-4 mr-2" />
            {action.label}
          </Button>
        ))}
      </div>

      {/* Main Grid Placeholder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-[#141414] border-[#2a2a2a]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono tracking-widest text-neutral-400 uppercase flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Atividade Recente
            </CardTitle>
          </CardHeader>
          <CardContent className="p-20 text-center text-neutral-600 font-mono text-xs">
             Sincronizando feed de atividades...
          </CardContent>
        </Card>

        <Card className="bg-[#141414] border-[#2a2a2a]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-mono tracking-widest text-neutral-400 uppercase flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Itens Pendentes
            </CardTitle>
          </CardHeader>
          <CardContent className="p-20 text-center text-neutral-600 font-mono text-xs">
             Verificando pendencias criticas...
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
