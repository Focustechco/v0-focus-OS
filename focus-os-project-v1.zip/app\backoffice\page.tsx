"use client"

import { PageWrapper } from "@/components/page-wrapper"
import { BackofficeModule } from "@/components/backoffice/backoffice-module"

export default function BackofficePage() {
  return (
    <PageWrapper title="BACKOFFICE" breadcrumb="BACKOFFICE">
      <BackofficeModule />
    </PageWrapper>
  )
}
