"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  TrendingUp,
  Award,
  AlertTriangle,
  ChevronDown,
} from "lucide-react"

type Period = "SEMANA" | "MES" | "TRIMESTRE"

const productivityData: Record<Period, { sector: string; percentage: number; tasks: number; hours: number; members: number }[]> = {
  SEMANA: [
    { sector: "Dev Backend", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Dev Frontend", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "DevSecOps", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Design", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Comercial", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Juridico", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "ADM", percentage: 0, tasks: 0, hours: 0, members: 0 },
  ],
  MES: [
    { sector: "Dev Backend", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Dev Frontend", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "DevSecOps", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Design", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Comercial", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Juridico", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "ADM", percentage: 0, tasks: 0, hours: 0, members: 0 },
  ],
  TRIMESTRE: [
    { sector: "Dev Backend", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Dev Frontend", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "DevSecOps", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Design", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Comercial", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "Juridico", percentage: 0, tasks: 0, hours: 0, members: 0 },
    { sector: "ADM", percentage: 0, tasks: 0, hours: 0, members: 0 },
  ],
}

const leaderboard: any[] = []

export function Produtividade() {
  const [period, setPeriod] = useState<Period>("SEMANA")
  const [expandedSector, setExpandedSector] = useState<string | null>(null)
  const [animated, setAnimated] = useState(false)

  const data = productivityData[period]
  const average = 0
  const highlight = { sector: "-", percentage: 0 }
  const alert = { sector: "-", percentage: 0 }

  useEffect(() => {
    setAnimated(false)
    const timer = setTimeout(() => setAnimated(true), 100)
    return () => clearTimeout(timer)
  }, [period])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-display font-bold text-white tracking-wide">
            PRODUTIVIDADE POR SETOR — {period === "SEMANA" ? "SEMANA ATUAL" : period === "MES" ? "MES ATUAL" : "TRIMESTRE ATUAL"}
          </h2>
          <p className="text-neutral-500 text-sm font-mono mt-1">analise de performance por area</p>
        </div>

        <div className="flex items-center gap-1 bg-[#141414] border border-[#2a2a2a] rounded p-1">
          {(["SEMANA", "MES", "TRIMESTRE"] as Period[]).map((p) => (
            <Button
              key={p}
              variant="ghost"
              size="sm"
              onClick={() => setPeriod(p)}
              className={`font-mono text-xs tracking-widest ${
                period === p
                  ? "bg-orange-500 text-white hover:bg-orange-600"
                  : "text-neutral-400 hover:text-white hover:bg-[#1a1a1a]"
              }`}
            >
              {p}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Bar Chart */}
        <div className="lg:col-span-3">
          <Card className="bg-[#141414] border-[#2a2a2a]">
            <CardContent className="p-6">
              <div className="space-y-4">
                {data.map((item, index) => (
                  <div key={item.sector}>
                    <div
                      className="cursor-pointer"
                      onClick={() => setExpandedSector(expandedSector === item.sector ? null : item.sector)}
                    >
                      <div className="flex items-center gap-4 mb-2">
                        <span className="text-neutral-400 font-mono text-sm w-28 truncate">{item.sector}</span>
                        <div className="flex-1 h-8 bg-[#1a1a1a] rounded relative overflow-hidden">
                          <div
                            className="absolute inset-y-0 left-0 bg-gradient-to-r from-orange-600 to-orange-400 rounded transition-all duration-800 ease-out flex items-center justify-end pr-3"
                            style={{
                              width: animated ? `${item.percentage}%` : "0%",
                              transitionDelay: `${index * 100}ms`,
                            }}
                          >
                            <span className="text-white font-mono text-sm font-bold">{item.percentage}%</span>
                          </div>
                        </div>
                        <ChevronDown
                          className={`w-4 h-4 text-neutral-500 transition-transform ${
                            expandedSector === item.sector ? "rotate-180" : ""
                          }`}
                        />
                      </div>
                    </div>

                    {expandedSector === item.sector && (
                      <div className="ml-32 p-4 bg-[#1a1a1a] rounded border border-[#2a2a2a] mb-4 animate-in slide-in-from-top-2 duration-200">
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <p className="text-neutral-500 text-xs font-mono uppercase">Tasks Concluidas</p>
                            <p className="text-white text-lg font-display font-bold">{item.tasks}</p>
                          </div>
                          <div>
                            <p className="text-neutral-500 text-xs font-mono uppercase">Horas Trabalhadas</p>
                            <p className="text-white text-lg font-display font-bold">{item.hours}h</p>
                          </div>
                          <div>
                            <p className="text-neutral-500 text-xs font-mono uppercase">Membros</p>
                            <p className="text-white text-lg font-display font-bold">{item.members}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Metric Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <Card className="bg-[#141414] border-[#2a2a2a]">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-neutral-500 text-xs font-mono uppercase mb-1">Media Geral</p>
                    <p className="text-3xl font-display font-bold text-white">{average}%</p>
                  </div>
                  <div className="w-10 h-10 rounded bg-orange-500/10 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-orange-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#141414] border-[#2a2a2a] border-l-2 border-l-green-500">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-neutral-500 text-xs font-mono uppercase mb-1">Setor Destaque</p>
                    <p className="text-xl font-display font-bold text-green-500">{highlight.sector}</p>
                    <p className="text-neutral-400 text-sm font-mono">{highlight.percentage}%</p>
                  </div>
                  <div className="w-10 h-10 rounded bg-green-500/10 flex items-center justify-center">
                    <Award className="w-5 h-5 text-green-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#141414] border-[#2a2a2a] border-l-2 border-l-red-500">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-neutral-500 text-xs font-mono uppercase mb-1">Setor em Alerta</p>
                    <p className="text-xl font-display font-bold text-red-500">{alert.sector}</p>
                    <p className="text-neutral-400 text-sm font-mono">{alert.percentage}%</p>
                  </div>
                  <div className="w-10 h-10 rounded bg-red-500/10 flex items-center justify-center">
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Leaderboard */}
        <div className="lg:col-span-1">
          <Card className="bg-[#141414] border-[#2a2a2a] h-full">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-mono tracking-widest text-neutral-400 uppercase flex items-center gap-2">
                <Award className="w-4 h-4 text-orange-500" />
                Ranking de Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {leaderboard.map((person) => (
                    <div
                      key={person.rank}
                      className={`flex items-center gap-3 p-3 rounded border transition-all ${
                        person.rank === 1
                          ? "bg-orange-500/10 border-orange-500/30"
                          : person.rank === 2
                          ? "bg-neutral-500/10 border-neutral-500/30"
                          : person.rank === 3
                          ? "bg-amber-700/10 border-amber-700/30"
                          : "bg-[#1a1a1a] border-[#2a2a2a]"
                      }`}
                    >
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono ${
                          person.rank === 1
                            ? "bg-orange-500 text-white"
                            : person.rank === 2
                            ? "bg-neutral-400 text-black"
                            : person.rank === 3
                            ? "bg-amber-700 text-white"
                            : "bg-[#2a2a2a] text-neutral-400"
                        }`}
                      >
                        {person.rank}
                      </span>
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-orange-500/20 text-orange-500 text-xs font-mono">
                          {person.initials}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-sm font-medium truncate">{person.name}</p>
                        <p className="text-neutral-500 text-xs font-mono">{person.sector}</p>
                      </div>
                      <Badge className="bg-[#1a1a1a] text-orange-500 font-mono text-xs">
                        {person.score}
                      </Badge>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
