"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useClientes } from "@/lib/hooks/use-clientes"
import { Loader2 } from "lucide-react"

interface QuickClientModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess: (client: any) => void
}

export function QuickClientModal({ open, onOpenChange, onSuccess }: QuickClientModalProps) {
  const { addClient } = useClientes()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    nome: "",
    empresa: "",
    email: "",
    telefone: ""
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.nome || !formData.empresa || !formData.email) return

    setIsSubmitting(true)
    try {
      const result = await addClient(formData)
      if (result?.data) {
        onSuccess(result.data)
        onOpenChange(false)
        setFormData({ nome: "", empresa: "", email: "", telefone: "" })
      }
    } catch (error) {
      console.error("Erro ao cadastrar cliente:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#141414] border-[#2A2A2A] text-white sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-display">Cadastrar Novo Cliente</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label className="text-neutral-400 text-xs font-mono uppercase">Nome Completo *</Label>
            <Input
              required
              placeholder="Ex: João Silva"
              className="bg-[#1A1A1A] border-[#2A2A2A]"
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label className="text-neutral-400 text-xs font-mono uppercase">Empresa *</Label>
            <Input
              required
              placeholder="Ex: TechCorp LTDA"
              className="bg-[#1A1A1A] border-[#2A2A2A]"
              value={formData.empresa}
              onChange={(e) => setFormData({ ...formData, empresa: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label className="text-neutral-400 text-xs font-mono uppercase">E-mail *</Label>
            <Input
              required
              type="email"
              placeholder="contato@empresa.com"
              className="bg-[#1A1A1A] border-[#2A2A2A]"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label className="text-neutral-400 text-xs font-mono uppercase">Telefone</Label>
            <Input
              placeholder="(00) 00000-0000"
              className="bg-[#1A1A1A] border-[#2A2A2A]"
              value={formData.telefone}
              onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
            />
          </div>
          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="ghost"
              onClick={() => onOpenChange(false)}
              className="text-neutral-400 hover:text-white"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-orange-500 hover:bg-orange-600 text-white min-w-[120px]"
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Salvar Cliente"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

