"use client"

import { useState, useEffect } from "react"
import { PageWrapper } from "@/components/page-wrapper"
import { ProfileIdentityCard } from "@/components/perfil/profile-identity-card"
import { ProfileForms } from "@/components/perfil/profile-forms"
import { supabase } from "@/lib/supabase"
import { toast } from "sonner"

export default function PerfilPage() {
  const [profile, setProfile] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  const loadProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const { data, error } = await supabase
        .from("perfil")
        .select("*")
        .eq("usuario_id", user.id)
        .maybeSingle()

      if (error) throw error

      if (data) {
        setProfile(data)
      } else {
        // Inicializar perfil se não existir
        const { data: newProfile, error: initError } = await supabase
          .from("perfil")
          .insert([{ 
            usuario_id: user.id, 
            nome_completo: user.user_metadata?.full_name || user.email?.split("@")[0],
            email_profissional: user.email
          }])
          .select()
          .single()
        
        if (initError) throw initError
        setProfile(newProfile)
      }
    } catch (error: any) {
      console.error("Erro ao carregar perfil:", error)
      toast.error("Erro ao carregar dados do perfil")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadProfile()
  }, [])

  if (loading) {
    return (
      <PageWrapper title="PERFIL" breadcrumb="PERSONALIZACAO">
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </PageWrapper>
    )
  }

  return (
    <PageWrapper title="PERFIL & IDENTIDADE" breadcrumb="CONFIGURACOES / PERFIL">
      <div className="grid grid-cols-1 lg:grid-cols-[35%_65%] gap-6">
        {/* Coluna Esquerda: Identidade Visual */}
        <div className="space-y-6">
          <ProfileIdentityCard profile={profile} onUpdate={loadProfile} />
        </div>

        {/* Coluna Direita: Formulários */}
        <div className="space-y-6">
          <ProfileForms profile={profile} onUpdate={loadProfile} />
        </div>
      </div>
    </PageWrapper>
  )
}
