"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import {
  ChevronLeft, ChevronUp, ChevronDown, Save, Eye, Download, X, Plus,
  CheckCircle2, Circle, GripVertical, AlertTriangle, BarChart2, Users,
  Flag, MessageSquare, ListTodo, Zap, Clock,
} from "lucide-react"
import { supabase } from "@/lib/supabase"
import { ReportPreview } from "./report-preview"

/* ─── Types ────────────────────────────────────────────── */
interface EditorSection {
  id: string
  icon: any
  label: string
  open: boolean
}

const SECTION_META: Record<string, { icon: any; label: string; color: string }> = {
  resumo:         { icon: FileIcon, label: "RESUMO EXECUTIVO", color: "text-orange-500" },
  status:         { icon: BarChart2, label: "STATUS ATUAL", color: "text-orange-500" },
  atividades:     { icon: CheckCircle2, label: "ATIVIDADES DO PERÍODO", color: "text-orange-500" },
  sprints:        { icon: Zap, label: "SPRINTS & ENTREGAS", color: "text-orange-500" },
  tasks_detalhadas: { icon: ListTodo, label: "TASKS DETALHADAS", color: "text-orange-500" },
  proximos_passos: { icon: Flag, label: "PRÓXIMOS PASSOS", color: "text-orange-500" },
  metricas:       { icon: BarChart2, label: "MÉTRICAS TÉCNICAS", color: "text-orange-500" },
  observacoes:    { icon: MessageSquare, label: "OBSERVAÇÕES DA EQUIPE", color: "text-orange-500" },
}

function FileIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
}

const SAUDE_OPTIONS = [
  { id: "verde", label: "No prazo", color: "text-green-400 border-green-500/30 bg-green-500/10" },
  { id: "amarelo", label: "Em risco", color: "text-yellow-400 border-yellow-500/30 bg-yellow-500/10" },
  { id: "vermelho", label: "Atrasado", color: "text-red-400 border-red-500/30 bg-red-500/10" },
]

const STATUS_OPTIONS = ["diagnostico", "planejamento", "desenvolvimento", "revisao", "entrega", "concluido"]

/* ─── Main Component ──────────────────────────────────── */
interface Props {
  reportId: string
  onBack: () => void
}

export function ReportEditorV2({ reportId, onBack }: Props) {
  const [report, setReport] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [lastSaved, setLastSaved] = useState<Date | null>(null)
  const [showPreview, setShowPreview] = useState(false)
  const autoSaveRef = useRef<NodeJS.Timeout | null>(null)

  // Section states
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({})
  const [resumoTexto, setResumoTexto] = useState("")
  const [resumoTags, setResumoTags] = useState<string[]>([])
  const [novaTag, setNovaTag] = useState("")
  const [addingTag, setAddingTag] = useState(false)
  const [statusEtapa, setStatusEtapa] = useState("")
  const [statusProgresso, setStatusProgresso] = useState(0)
  const [statusSaude, setStatusSaude] = useState("verde")
  const [statusEntrega, setStatusEntrega] = useState("")
  const [statusContexto, setStatusContexto] = useState("")
  const [atividades, setAtividades] = useState<any[]>([])
  const [novaAtividade, setNovaAtividade] = useState("")
  const [addingAtividade, setAddingAtividade] = useState(false)
  const [proximosPassos, setProximosPassos] = useState<any[]>([])
  const [novoProximo, setNovoProximo] = useState("")
  const [observacoes, setObservacoes] = useState("")

  /* ── Load report ─────────────────────────────────────── */
  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from("relatorios")
        .select("*, projetos(nome, codigo, status, prazo)")
        .eq("id", reportId)
        .single()
      if (!data) return
      setReport(data)

      // A coluna real da tabela é 'conteudo' (não conteudo_json)
      const fullContent = data.conteudo ?? data.conteudo_json ?? {}
      const cfg = fullContent?.configuracao ?? {}
      const content = fullContent ?? {}
      const secoes = cfg.secoes ?? {}
      const enabledSections = Object.entries(secoes).filter(([, v]) => v).map(([k]) => k)

      // Initialize open state for enabled sections
      setOpenSections(Object.fromEntries(enabledSections.map((k) => [k, true])))

      // Load fields
      const meta = content.meta ?? {}
      const proj = data.projetos

      setStatusEtapa(data.etapa_atual ?? proj?.status ?? "desenvolvimento")
      setStatusProgresso(meta.progresso ?? data.progresso ?? 0)
      setStatusSaude(meta.saude === "verde" ? "verde" : meta.saude === "vermelho" ? "vermelho" : "amarelo")
      setStatusEntrega(proj?.prazo?.split("T")[0] ?? "")

      const dateS = new Date(data.periodo_inicio).toLocaleDateString("pt-BR")
      const dateE = new Date(data.periodo_fim).toLocaleDateString("pt-BR")
      setResumoTexto(
        `O projeto ${proj?.nome ?? "—"} está em andamento, atualmente na etapa de ${data.etapa_atual ?? "desenvolvimento"}. ` +
        `Este relatório apresenta o progresso realizado durante o período de ${dateS} a ${dateE}, ` +
        `incluindo entregas concluídas, atividades em andamento e próximos passos planejados.`
      )

      // Load sections data
      const sCliente = content.sections
      if (sCliente?.oQuefoiFeito?.grupos) {
        const tasks: any[] = []
        sCliente.oQuefoiFeito.grupos.forEach((g: any) => g.tarefas?.forEach((t: any) => tasks.push({ ...t, id: Math.random().toString() })))
        setAtividades(tasks.slice(0, 8))
      }
      if (sCliente?.proximosPassos?.tarefas) {
        setProximosPassos(sCliente.proximosPassos.tarefas.slice(0, 6))
      }

      setIsLoading(false)
    }
    load()
  }, [reportId])

  /* ── Auto-save every 45s ─────────────────────────────── */
  useEffect(() => {
    if (!report) return
    autoSaveRef.current = setInterval(async () => {
      await doSave("rascunho", true)
    }, 45_000)
    return () => { if (autoSaveRef.current) clearInterval(autoSaveRef.current) }
  }, [report, resumoTexto, statusEtapa, statusProgresso, statusSaude, atividades, observacoes])

  const buildSavePayload = useCallback(() => ({
    conteudo: {
      ...(report?.conteudo ?? report?.conteudo_json ?? {}),
      editor: {
        resumo: resumoTexto,
        tags: resumoTags,
        etapa: statusEtapa,
        progresso: statusProgresso,
        saude: statusSaude,
        entregaPrevista: statusEntrega,
        contextoStatus: statusContexto,
        atividades,
        proximosPassos,
        observacoes,
      },
    },
  }), [report, resumoTexto, resumoTags, statusEtapa, statusProgresso, statusSaude, statusEntrega, statusContexto, atividades, proximosPassos, observacoes])

  async function doSave(status = "salvo", silent = false) {
    if (!report || isSaving) return
    if (!silent) setIsSaving(true)
    const payload = buildSavePayload()
    await supabase.from("relatorios").update({ ...payload, status }).eq("id", reportId)
    setLastSaved(new Date())
    if (!silent) setIsSaving(false)
  }

  async function handleExport() {
    // html2pdf fallback for now
    await doSave("exportado")
    const win = window.open(`/relatorios/${reportId}/preview`, "_blank")
    if (!win) window.print()
  }

  function toggleSection(id: string) {
    setOpenSections((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  if (isLoading) return (
    <div className="flex items-center justify-center h-screen bg-[#0A0A0A]">
      <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
    </div>
  )

  const proj = report?.projetos
  const enabledSections = Object.entries(report?.conteudo_json?.configuracao?.secoes ?? {})
    .filter(([, v]) => v)
    .map(([k]) => k)

  return (
    <div className="flex flex-col h-screen bg-[#0A0A0A] overflow-hidden">
      {/* ── Fixed Header ─────────────────────────────────── */}
      <header className="flex items-center justify-between px-6 py-4 bg-[#0A0A0A] border-b border-[#1A1A1A] flex-shrink-0 z-20">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack} className="text-neutral-400 hover:text-white gap-2 -ml-2">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Button>
          <div className="h-4 w-px bg-[#2A2A2A]" />
          <div>
            <h1 className="text-sm font-bold text-white">{report?.titulo}</h1>
            {lastSaved && (
              <p className="text-[10px] text-neutral-600 flex items-center gap-1 mt-0.5">
                <Clock className="w-2.5 h-2.5" />
                Salvo automaticamente às {lastSaved.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={() => doSave()}
            disabled={isSaving}
            variant="outline"
            className="border-[#2A2A2A] text-neutral-300 hover:text-white hover:border-neutral-500 gap-2 text-xs"
          >
            <Save className="w-3.5 h-3.5" />
            {isSaving ? "Salvando..." : "Salvar"}
          </Button>
          <Button onClick={() => setShowPreview(true)} className="bg-orange-500 hover:bg-orange-600 text-white gap-2 text-xs">
            <Eye className="w-3.5 h-3.5" /> Preview
          </Button>
          <Button onClick={handleExport} className="bg-orange-500 hover:bg-orange-600 text-white gap-2 text-xs">
            <Download className="w-3.5 h-3.5" /> Exportar
          </Button>
        </div>
      </header>

      {/* ── Content ──────────────────────────────────────── */}
      <main className="flex-1 overflow-y-auto p-6 space-y-3 max-w-4xl mx-auto w-full">

        {/* RESUMO EXECUTIVO */}
        {enabledSections.includes("resumo") && (
          <Section id="resumo" open={openSections["resumo"]} toggle={toggleSection}>
            <div className="p-4 bg-[#0A0A0A] rounded-lg border border-orange-500/10 mb-3">
              <textarea
                value={resumoTexto}
                onChange={(e) => setResumoTexto(e.target.value)}
                rows={4}
                className="w-full bg-transparent text-sm text-neutral-300 leading-relaxed resize-none outline-none"
              />
            </div>
            {/* Tags */}
            <div className="flex flex-wrap items-center gap-2">
              {resumoTags.map((tag) => (
                <span key={tag} className="flex items-center gap-1.5 px-2.5 py-1 bg-[#1A1A1A] border border-[#2A2A2A] rounded-full text-xs text-neutral-300">
                  {tag}
                  <button onClick={() => setResumoTags((t) => t.filter((x) => x !== tag))}>
                    <X className="w-3 h-3 text-neutral-600 hover:text-red-400" />
                  </button>
                </span>
              ))}
              {addingTag ? (
                <input
                  autoFocus
                  value={novaTag}
                  onChange={(e) => setNovaTag(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && novaTag.trim()) {
                      setResumoTags((t) => [...t, novaTag.trim()])
                      setNovaTag("")
                      setAddingTag(false)
                    }
                    if (e.key === "Escape") { setAddingTag(false); setNovaTag("") }
                  }}
                  placeholder="Nova tag..."
                  className="px-2.5 py-1 bg-[#1A1A1A] border border-orange-500 rounded-full text-xs text-white outline-none w-24"
                />
              ) : (
                <button
                  onClick={() => setAddingTag(true)}
                  className="flex items-center gap-1 px-2.5 py-1 border border-dashed border-[#2A2A2A] rounded-full text-xs text-neutral-600 hover:border-orange-500 hover:text-orange-500 transition-colors"
                >
                  <Plus className="w-3 h-3" /> Nova tag...
                </button>
              )}
            </div>
          </Section>
        )}

        {/* STATUS ATUAL */}
        {enabledSections.includes("status") && (
          <Section id="status" open={openSections["status"]} toggle={toggleSection}>
            <div className="space-y-4">
              {/* Etapa */}
              <div className="flex items-center gap-4">
                <span className="text-xs text-neutral-500 w-32 flex-shrink-0">Etapa:</span>
                <select
                  value={statusEtapa}
                  onChange={(e) => setStatusEtapa(e.target.value)}
                  className="bg-orange-500 text-white text-xs font-bold px-3 py-1.5 rounded-full border-none outline-none cursor-pointer"
                >
                  {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                </select>
              </div>
              {/* Progresso */}
              <div className="flex items-center gap-4">
                <span className="text-xs text-neutral-500 w-32 flex-shrink-0">Progresso:</span>
                <div className="flex-1 flex items-center gap-3">
                  <input
                    type="range" min={0} max={100}
                    value={statusProgresso}
                    onChange={(e) => setStatusProgresso(Number(e.target.value))}
                    className="flex-1 accent-orange-500"
                  />
                  <span className="text-sm font-mono text-white w-10 text-right">{statusProgresso}%</span>
                </div>
              </div>
              {/* Saúde */}
              <div className="flex items-center gap-4">
                <span className="text-xs text-neutral-500 w-32 flex-shrink-0">Saúde:</span>
                <div className="flex items-center gap-2">
                  {SAUDE_OPTIONS.map((o) => (
                    <button
                      key={o.id}
                      onClick={() => setStatusSaude(o.id)}
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all",
                        statusSaude === o.id ? o.color : "border-[#2A2A2A] text-neutral-600 bg-transparent hover:border-neutral-500"
                      )}
                    >
                      <span className={cn("w-1.5 h-1.5 rounded-full",
                        o.id === "verde" ? "bg-green-400" : o.id === "amarelo" ? "bg-yellow-400" : "bg-red-400"
                      )} />
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>
              {/* Entrega prevista */}
              <div className="flex items-center gap-4">
                <span className="text-xs text-neutral-500 w-32 flex-shrink-0">Entrega prevista:</span>
                <input
                  type="date"
                  value={statusEntrega}
                  onChange={(e) => setStatusEntrega(e.target.value)}
                  className="bg-[#0A0A0A] border border-[#2A2A2A] rounded px-3 py-1.5 text-sm text-white [color-scheme:dark] outline-none focus:border-orange-500"
                />
              </div>
              {/* Contexto */}
              <textarea
                value={statusContexto}
                onChange={(e) => setStatusContexto(e.target.value)}
                rows={3}
                placeholder="Adicione contexto sobre o status atual para o cliente..."
                className="w-full bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg px-4 py-3 text-sm text-neutral-300 placeholder:text-neutral-700 outline-none focus:border-orange-500/50 resize-none"
              />
            </div>
          </Section>
        )}

        {/* ATIVIDADES DO PERÍODO */}
        {enabledSections.includes("atividades") && (
          <Section id="atividades" open={openSections["atividades"]} toggle={toggleSection}>
            <div className="space-y-1">
              {atividades.map((t, i) => (
                <div key={t.id ?? i} className="flex items-center gap-3 py-2 px-3 rounded hover:bg-[#1A1A1A] group">
                  <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                  {t.data && (
                    <span className="text-[11px] font-mono text-neutral-600 w-12 flex-shrink-0">
                      {new Date(t.data).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
                    </span>
                  )}
                  <span className="flex-1 text-sm text-neutral-300">{t.titulo}</span>
                  <button onClick={() => setAtividades((a) => a.filter((_, j) => j !== i))}
                    className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <X className="w-3.5 h-3.5 text-neutral-600 hover:text-red-400" />
                  </button>
                </div>
              ))}
              {addingAtividade ? (
                <input
                  autoFocus
                  value={novaAtividade}
                  onChange={(e) => setNovaAtividade(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && novaAtividade.trim()) {
                      setAtividades((a) => [...a, { titulo: novaAtividade.trim(), id: Math.random().toString(), data: new Date().toISOString() }])
                      setNovaAtividade("")
                      setAddingAtividade(false)
                    }
                    if (e.key === "Escape") { setAddingAtividade(false); setNovaAtividade("") }
                  }}
                  placeholder="Descrição da atividade..."
                  className="w-full bg-[#1A1A1A] border border-orange-500 rounded px-3 py-2 text-sm text-white outline-none mt-1"
                />
              ) : (
                <button
                  onClick={() => setAddingAtividade(true)}
                  className="flex items-center gap-2 mt-2 text-xs text-neutral-600 hover:text-orange-500 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" /> Adicionar atividade
                </button>
              )}
            </div>
          </Section>
        )}

        {/* PRÓXIMOS PASSOS */}
        {enabledSections.includes("proximos_passos") && (
          <Section id="proximos_passos" open={openSections["proximos_passos"]} toggle={toggleSection}>
            <div className="space-y-2">
              {proximosPassos.map((t, i) => (
                <div key={i} className="flex items-start gap-3 py-2 group">
                  <span className="text-sm font-mono text-orange-500 w-5 flex-shrink-0 mt-0.5">{i + 1}.</span>
                  <span className="flex-1 text-sm text-neutral-300">{t.titulo}</span>
                  {t.responsavel && <span className="text-xs text-orange-400">– {t.responsavel}</span>}
                  {t.prazo && (
                    <span className="text-xs text-neutral-600 flex-shrink-0">
                      até {new Date(t.prazo).toLocaleDateString("pt-BR")}
                    </span>
                  )}
                  <button onClick={() => setProximosPassos((p) => p.filter((_, j) => j !== i))}
                    className="opacity-0 group-hover:opacity-100 transition-opacity ml-2">
                    <X className="w-3.5 h-3.5 text-neutral-600 hover:text-red-400" />
                  </button>
                </div>
              ))}
              <button
                onClick={() => {
                  const txt = window.prompt("Próximo passo:")
                  if (txt) setProximosPassos((p) => [...p, { titulo: txt }])
                }}
                className="flex items-center gap-2 mt-2 text-xs text-neutral-600 hover:text-orange-500 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Adicionar próximo passo
              </button>
            </div>
          </Section>
        )}

        {/* OBSERVAÇÕES DA EQUIPE */}
        {enabledSections.includes("observacoes") && (
          <Section id="observacoes" open={openSections["observacoes"]} toggle={toggleSection}>
            <textarea
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
              rows={5}
              placeholder="Observações internas da equipe (não aparece no relatório para cliente)..."
              className="w-full bg-[#0A0A0A] border border-[#2A2A2A] rounded-lg px-4 py-3 text-sm text-neutral-300 placeholder:text-neutral-700 outline-none focus:border-orange-500/50 resize-none"
            />
          </Section>
        )}
      </main>

      {/* ── Preview Modal ─────────────────────────────────── */}
      {showPreview && (
        <ReportPreview
          report={report}
          editorData={{ resumoTexto, resumoTags, statusEtapa, statusProgresso, statusSaude, statusEntrega, atividades, proximosPassos, observacoes }}
          onClose={() => setShowPreview(false)}
        />
      )}
    </div>
  )
}

/* ─── Collapsible Section Wrapper ───────────────────── */
function Section({ id, open, toggle, children }: any) {
  const meta = SECTION_META[id] ?? { icon: FileIcon, label: id.toUpperCase(), color: "text-orange-500" }
  const Icon = meta.icon

  return (
    <div className="rounded-xl border border-[#1A1A1A] bg-[#111111] overflow-hidden">
      <button
        onClick={() => toggle(id)}
        className="w-full flex items-center gap-3 px-5 py-4 hover:bg-[#1A1A1A] transition-colors"
      >
        <Icon className={cn("w-4 h-4 flex-shrink-0", meta.color)} />
        <span className={cn("flex-1 text-xs font-mono font-bold tracking-[0.15em] text-left", meta.color)}>
          {meta.label}
        </span>
        {open ? <ChevronUp className="w-4 h-4 text-neutral-600" /> : <ChevronDown className="w-4 h-4 text-neutral-600" />}
      </button>
      {open && <div className="px-5 pb-5 pt-1">{children}</div>}
    </div>
  )
}
