import useSWR from "swr"
import { useEffect } from "react"
import { supabase } from "@/lib/supabase"

export interface BackofficeItem {
  id: string
  nome: string
  empresa: string
  status: string
  valor: number
  origem: string
  criado_em: string
}

export function useBackoffice() {
  const checkAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession()
    return !!session
  }

  const fetcher = async () => {
    await checkAuth()
    const { data, error } = await supabase
      .from("leads")
      .select("*")
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Erro ao buscar backoffice (leads):", JSON.stringify(error, null, 2))
      throw error
    }

    return (data || []).map(item => ({
      ...item,
      criado_em: item.created_at
    }))
  }

  const { data, error, isLoading, mutate } = useSWR("backoffice-leads", fetcher)

  useEffect(() => {
    const channelId = `backoffice_realtime_${Math.random().toString(36).substring(2, 9)}`
    const channel = supabase.channel(channelId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'leads' }, () => mutate())
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [mutate])

  return {
    items: data || [],
    isLoading,
    isError: error,
    mutate
  }
}

// Alias para compatibilidade legada
export { useBackoffice as useBacklog }
