"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  FileSpreadsheet,
  ExternalLink,
  Download,
  FileText,
  GripVertical,
  Clock,
} from "lucide-react"
import { useAdmTasks } from "@/lib/hooks/use-adm-tarefas"

const priorityColors: Record<string, string> = {
  alta: "bg-red-500",
  media: "bg-yellow-500",
  baixa: "bg-neutral-500",
}

const columnColors: Record<string, string> = {
  "A FAZER": "border-neutral-500",
  "EM ANDAMENTO": "border-orange-500",
  "CONCLUIDO": "border-green-500",
}

export function Adm() {
  const { tasks, isLoading } = useAdmTasks()
  
  // Real sheets/docs hooks could be added here later
  const [sheets] = useState<any[]>([])
  const [documents] = useState<any[]>([])

  const kanbanTasks = {
    "A FAZER": tasks.filter(t => t.status === "A FAZER"),
    "EM ANDAMENTO": tasks.filter(t => t.status === "EM ANDAMENTO"),
    "CONCLUIDO": tasks.filter(t => t.status === "CONCLUIDO"),
  }

  return (
    <div className="space-y-6">
      {/* Quick Links Section */}
      <div>
        <h2 className="text-sm font-mono tracking-widest text-neutral-400 uppercase mb-4 flex items-center gap-2 border-l-2 border-orange-500 pl-3">
          Links Rapidos — Planilhas & Ferramentas
        </h2>
        {sheets.length === 0 ? (
           <div className="p-8 border border-[#2a2a2a] rounded text-center text-neutral-500 font-mono text-sm max-w-4xl">Nenhuma planilha vinculada.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {sheets.map((sheet) => (
              <Card
                key={sheet.name}
                className="bg-[#141414] border-[#2a2a2a] hover:border-orange-500/30 transition-all group cursor-pointer"
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded bg-green-500/10 flex items-center justify-center">
                      <FileSpreadsheet className="w-5 h-5 text-green-500" />
                    </div>
                    {sheet.recent && (
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-500 opacity-75" />
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500" />
                      </span>
                    )}
                  </div>
                  <h3 className="text-white font-medium text-sm mb-1">{sheet.name}</h3>
                  <p className="text-neutral-600 text-xs font-mono flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {sheet.updatedAt}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full mt-3 bg-transparent text-orange-500 hover:text-orange-400 hover:bg-orange-500/10 font-mono text-xs tracking-widest uppercase"
                  >
                    Abrir
                    <ExternalLink className="w-3 h-3 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Kanban Section */}
      <div>
        <h2 className="text-sm font-mono tracking-widest text-neutral-400 uppercase mb-4 flex items-center gap-2 border-l-2 border-orange-500 pl-3">
          Tarefas Administrativas
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {Object.entries(kanbanTasks).map(([column, columnTasks]) => (
            <Card key={column} className={`bg-[#141414] border-[#2a2a2a] border-t-2 ${columnColors[column]}`}>
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-mono tracking-widest text-neutral-400 uppercase flex items-center justify-between">
                  {column}
                  <Badge variant="secondary" className="bg-[#1a1a1a] text-neutral-400 text-[10px]">
                    {columnTasks.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {isLoading && columnTasks.length === 0 ? (
                  <p className="text-neutral-600 text-xs text-center font-mono py-4">Carregando...</p>
                ) : columnTasks.length === 0 ? (
                  <p className="text-neutral-600 text-xs text-center font-mono py-4">Vazio</p>
                ) : (
                  columnTasks.map((task, index) => (
                    <div
                      key={task.id || index}
                      className="p-3 bg-[#1a1a1a] rounded border border-[#2a2a2a] hover:border-orange-500/30 transition-all group"
                    >
                      <div className="flex items-start gap-2">
                        <GripVertical className="w-4 h-4 text-neutral-600 opacity-0 group-hover:opacity-100 transition-opacity cursor-grab" />
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium mb-2">{task.title}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Avatar className="w-5 h-5">
                                <AvatarFallback className="bg-orange-500/20 text-orange-500 text-[9px]">
                                  {task.assignee || "??"}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-neutral-500 text-xs font-mono">{task.due_date || "-"}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className={`w-2 h-2 rounded-full ${priorityColors[task.priority || "baixa"]}`} />
                              <Badge className="bg-[#222] text-neutral-400 text-[9px] font-mono">
                                {task.tag || "GERAL"}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Documents Section */}
      <div>
        <h2 className="text-sm font-mono tracking-widest text-neutral-400 uppercase mb-4 flex items-center gap-2 border-l-2 border-orange-500 pl-3">
          Documentos Internos
        </h2>
        <Card className="bg-[#141414] border-[#2a2a2a]">
          <CardContent className="p-0">
            {documents.length === 0 ? (
              <p className="text-neutral-500 p-8 text-center font-mono text-sm">Nenhum documento encontrado.</p>
            ) : (
              <ScrollArea className="w-full">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#2a2a2a]">
                      <th className="text-left p-4 text-neutral-500 font-mono text-xs tracking-wider uppercase">Nome</th>
                      <th className="text-left p-4 text-neutral-500 font-mono text-xs tracking-wider uppercase">Tipo</th>
                      <th className="text-left p-4 text-neutral-500 font-mono text-xs tracking-wider uppercase">Tamanho</th>
                      <th className="text-left p-4 text-neutral-500 font-mono text-xs tracking-wider uppercase">Enviado Por</th>
                      <th className="text-left p-4 text-neutral-500 font-mono text-xs tracking-wider uppercase">Data</th>
                      <th className="text-right p-4 text-neutral-500 font-mono text-xs tracking-wider uppercase"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {documents.map((doc, index) => (
                      <tr
                        key={index}
                        className="border-b border-[#2a2a2a] hover:bg-[#1f1f1f] hover:border-l-2 hover:border-l-orange-500 transition-all"
                      >
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <FileText className="w-4 h-4 text-orange-500" />
                            <span className="text-white text-sm">{doc.name}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge className="bg-[#1a1a1a] text-neutral-400 text-[10px] font-mono">
                            {doc.type}
                          </Badge>
                        </td>
                        <td className="p-4 text-neutral-400 font-mono text-sm">{doc.size}</td>
                        <td className="p-4 text-neutral-300 text-sm">{doc.uploadedBy}</td>
                        <td className="p-4 text-neutral-400 font-mono text-sm">{doc.date}</td>
                        <td className="p-4">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-neutral-400 hover:text-orange-500 hover:bg-orange-500/10"
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
