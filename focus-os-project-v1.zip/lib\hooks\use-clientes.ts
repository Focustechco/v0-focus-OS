import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'

export type Cliente = {
  id: string
  nome: string
  empresa: string
  email?: string
  telefone?: string
  observacoes?: string
  created_at: string
}

export function useClientes() {
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const fetchClientes = async () => {
    try {
      const { data, error } = await supabase
        .from('clientes')
        .select('*')
        .order('nome', { ascending: true })
      
      if (error) {
        console.error("Erro ao buscar clientes:", error)
        return
      }
      
      if (data) setClientes(data)
    } finally {
      setIsLoading(false)
    }
  }

  const addCliente = async (cliente: any) => {
    const { data, error } = await supabase
      .from('clientes')
      .insert({
        ...cliente,
        // Ensure some fields are mapped correctly if names differ
        nome: cliente.nome || cliente.name,
        empresa: cliente.empresa || cliente.company
      })
      .select()
      .single()
      
    if (!error && data) {
      setClientes(prev => [...prev, data])
    }
    return { data, error }
  }

  useEffect(() => { 
    fetchClientes() 
    
    // Use unique channel ID per instance to avoid "callbacks after subscribe()" error
    const channelId = `clientes_realtime_${Math.random().toString(36).substring(2, 9)}`
    const channel = supabase.channel(channelId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'clientes' }, () => fetchClientes())
      .subscribe()
      
    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  return { 
    clientes, 
    isLoading, 
    addCliente, 
    refetch: fetchClientes,
    // Keep legacy aliases for a smooth transition if needed
    clients: clientes,
    addClient: addCliente
  }
}

// Global alias to fix "useClients is not defined"
export { useClientes as useClients }

