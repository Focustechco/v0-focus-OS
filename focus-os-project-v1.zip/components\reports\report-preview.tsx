"use client"

import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { X, Download, Printer } from "lucide-react"
import { cn } from "@/lib/utils"

interface PreviewProps {
  report: any
  editorData: {
    resumoTexto: string
    resumoTags: string[]
    statusEtapa: string
    statusProgresso: number
    statusSaude: string
    statusEntrega: string
    atividades: any[]
    proximosPassos: any[]
    observacoes: string
  }
  onClose: () => void
}

const SAUDE_MAP: Record<string, { label: string; color: string }> = {
  verde:   { label: "No prazo", color: "#22c55e" },
  amarelo: { label: "Em risco", color: "#eab308" },
  vermelho:{ label: "Atrasado", color: "#ef4444" },
}

export function ReportPreview({ report, editorData, onClose }: PreviewProps) {
  const docRef = useRef<HTMLDivElement>(null)
  const proj = report?.projetos
  const cfg = report?.conteudo_json?.configuracao ?? {}

  const dateS = report?.periodo_inicio
    ? new Date(report.periodo_inicio).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })
    : "—"
  const dateE = report?.periodo_fim
    ? new Date(report.periodo_fim).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })
    : "—"
  const dateAll = new Date().toLocaleDateString("pt-BR")

  const saude = SAUDE_MAP[editorData.statusSaude] ?? SAUDE_MAP.amarelo

  async function handlePrint() {
    window.print()
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex flex-col overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-6 py-3 bg-[#1A1A1A] border-b border-[#2A2A2A] flex-shrink-0">
        <h3 className="text-sm font-mono font-bold text-white tracking-wider">PREVIEW DO RELATÓRIO</h3>
        <div className="flex items-center gap-2">
          <Button onClick={handlePrint} className="bg-orange-500 hover:bg-orange-600 text-white gap-2 text-xs h-8">
            <Printer className="w-3.5 h-3.5" /> Imprimir / PDF
          </Button>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-neutral-400 hover:text-white h-8 w-8">
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Document area */}
      <div className="flex-1 overflow-y-auto bg-neutral-200 flex items-start justify-center py-8 px-4">
        <div
          ref={docRef}
          className="bg-white w-full max-w-[760px] min-h-[1000px] shadow-2xl print:shadow-none"
          style={{ fontFamily: "'Inter', 'Helvetica Neue', sans-serif", color: "#1a1a1a" }}
        >
          {/* ── Document Header ───────────────────────── */}
          <div className="flex items-start justify-between px-12 pt-10 pb-6">
            {/* Logo Focus */}
            <div className="flex items-center gap-2.5">
              <div style={{
                width: 36, height: 36, borderRadius: 8,
                backgroundColor: "#FF6B00", display: "flex", alignItems: "center", justifyContent: "center"
              }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="white" />
                  <circle cx="12" cy="12" r="3" fill="white" />
                </svg>
              </div>
              <div>
                <p style={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.08em", color: "#1a1a1a" }}>FOCUS OS</p>
                <p style={{ fontSize: 10, color: "#888" }}>Sistema de Gestão</p>
              </div>
            </div>
            <p style={{ fontSize: 11, color: "#666" }}>Data: {dateAll}</p>
          </div>

          {/* ── Title block ───────────────────────────── */}
          <div className="px-12 pb-4">
            <h1 style={{ fontSize: 22, fontWeight: 800, letterSpacing: "0.02em", color: "#1a1a1a", marginBottom: 4 }}>
              RELATÓRIO DE PROGRESSO
            </h1>
            <p style={{ fontSize: 13, color: "#555", marginBottom: 4 }}>
              {proj?.nome ?? "Projeto"} – {dateS} a {dateE}
            </p>
            {cfg.preparadoPor && (
              <p style={{ fontSize: 12, color: "#888" }}>Preparado por: {cfg.preparadoPor}</p>
            )}
            {/* Orange divider */}
            <div style={{ height: 2, backgroundColor: "#FF6B00", marginTop: 16, borderRadius: 1 }} />
          </div>

          {/* ── Sections ──────────────────────────────── */}
          <div className="px-12 pb-12 space-y-8 mt-2">

            {/* 1. Resumo Executivo */}
            <PreviewSection number={1} title="RESUMO EXECUTIVO">
              <p style={{ fontSize: 13, lineHeight: 1.75, color: "#333" }}>{editorData.resumoTexto}</p>
              {editorData.resumoTags.length > 0 && (
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
                  {editorData.resumoTags.map((tag) => (
                    <span key={tag} style={{
                      padding: "2px 10px", border: "1px solid #ddd",
                      borderRadius: 100, fontSize: 11, color: "#555"
                    }}>{tag}</span>
                  ))}
                </div>
              )}
            </PreviewSection>

            {/* 2. Status Atual */}
            <PreviewSection number={2} title="STATUS ATUAL">
              <div style={{
                border: "1px solid #eee", borderRadius: 8, overflow: "hidden"
              }}>
                {[
                  {
                    label: "Etapa:", value: (
                      <span style={{ color: "#FF6B00", fontWeight: 700, fontSize: 12 }}>
                        {editorData.statusEtapa?.charAt(0).toUpperCase()}{editorData.statusEtapa?.slice(1)}
                      </span>
                    )
                  },
                  {
                    label: "Progresso:", value: (
                      <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1 }}>
                        <div style={{ flex: 1, height: 8, backgroundColor: "#eee", borderRadius: 4, overflow: "hidden" }}>
                          <div style={{ width: `${editorData.statusProgresso}%`, height: "100%", backgroundColor: "#FF6B00", borderRadius: 4 }} />
                        </div>
                        <span style={{ fontSize: 12, fontWeight: 700, color: "#1a1a1a", minWidth: 32 }}>
                          {editorData.statusProgresso}%
                        </span>
                      </div>
                    )
                  },
                  {
                    label: "Status:", value: (
                      <span style={{ color: saude.color, fontWeight: 600, fontSize: 12 }}>
                        ● {saude.label}
                      </span>
                    )
                  },
                ].map(({ label, value }, i) => (
                  <div key={label} style={{
                    display: "flex", alignItems: "center", gap: 16,
                    padding: "10px 16px",
                    backgroundColor: i % 2 === 0 ? "#fafafa" : "white",
                    borderBottom: i < 2 ? "1px solid #eee" : "none"
                  }}>
                    <span style={{ fontSize: 12, color: "#666", width: 100, flexShrink: 0 }}>{label}</span>
                    <div style={{ flex: 1, display: "flex", alignItems: "center" }}>{value}</div>
                  </div>
                ))}
              </div>
            </PreviewSection>

            {/* 3. Atividades do Período */}
            {editorData.atividades.length > 0 && (
              <PreviewSection number={3} title="ATIVIDADES DO PERÍODO">
                <div className="space-y-1">
                  {editorData.atividades.map((t, i) => (
                    <div key={i} style={{ display: "flex", gap: 16, padding: "5px 0", borderBottom: "1px solid #f0f0f0", alignItems: "baseline" }}>
                      {t.data && (
                        <span style={{ fontSize: 11, color: "#FF6B00", fontWeight: 700, width: 42, flexShrink: 0 }}>
                          {new Date(t.data).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" })}
                        </span>
                      )}
                      <span style={{ fontSize: 13, color: "#333", flex: 1 }}>{t.titulo}</span>
                    </div>
                  ))}
                </div>
              </PreviewSection>
            )}

            {/* 4. Próximos Passos */}
            {editorData.proximosPassos.length > 0 && (
              <PreviewSection number={4} title="PRÓXIMOS PASSOS">
                <div className="space-y-1.5">
                  {editorData.proximosPassos.map((t, i) => (
                    <div key={i} style={{ display: "flex", gap: 10, alignItems: "baseline" }}>
                      <span style={{ fontSize: 13, color: "#FF6B00", fontWeight: 700, minWidth: 20 }}>{i + 1}.</span>
                      <span style={{ fontSize: 13, color: "#333", flex: 1 }}>{t.titulo}</span>
                      {t.responsavel && (
                        <span style={{ fontSize: 11, color: "#FF6B00", flexShrink: 0 }}>– {t.responsavel}</span>
                      )}
                      {t.prazo && (
                        <span style={{ fontSize: 11, color: "#999", flexShrink: 0 }}>
                          até {new Date(t.prazo).toLocaleDateString("pt-BR")}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </PreviewSection>
            )}
          </div>

          {/* ── Footer ───────────────────────────────── */}
          <div style={{ borderTop: "1px solid #eee", margin: "0 48px", paddingTop: 16, paddingBottom: 32 }}>
            {cfg.incluirLogoCliente && cfg.logoClienteFile ? (
              <div style={{ display: "flex", justifyContent: "center" }}>
                <img src={cfg.logoClienteFile} alt="Logo cliente" style={{ maxHeight: 40, objectFit: "contain" }} />
              </div>
            ) : (
              <p style={{ textAlign: "center", fontSize: 10, color: "#bbb" }}>
                Gerado por Focus OS · {dateAll}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Print styles */}
      <style>{`
        @media print {
          body * { visibility: hidden; }
          [data-preview-doc], [data-preview-doc] * { visibility: visible; }
          [data-preview-doc] { position: fixed; left: 0; top: 0; width: 100%; }
        }
      `}</style>
    </div>
  )
}

function PreviewSection({ number, title, children }: { number: number; title: string; children: React.ReactNode }) {
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <div style={{ width: 3, height: 20, backgroundColor: "#FF6B00", borderRadius: 2, flexShrink: 0 }} />
        <h2 style={{ fontSize: 12, fontWeight: 800, letterSpacing: "0.12em", color: "#FF6B00" }}>
          {number}. {title}
        </h2>
      </div>
      {children}
    </div>
  )
}
